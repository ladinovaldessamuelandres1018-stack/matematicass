# Suite Matemática y Algorítmica

Proyecto integrador de lógica, matemáticas y desarrollo web con HTML5, CSS3 y JavaScript ES6+.

## Módulos
- **A. Simulador BairesDev:** probabilidad de dos dados, combinaciones de torneo, conteo de múltiplos, viajes mínimos, edades y verificación de porcentajes.
- **B. Motor cuadrático:** ecuaciones cuadráticas, lineales y degeneradas; raíces reales o complejas; discriminante, vértice y gráfica Canvas. Para raíces reales distintas usa la fórmula estable `q = -0.5 * (b + sign(b) * sqrt(delta))`, luego `x1 = q/a` y `x2 = c/q`.
- **C. Detector de secuencias:** diferencias sucesivas, patrones aritméticos, de segundo orden, geométricos y detección básica de ciclos.
- **D. Pruebas:** diez pruebas automáticas visibles en la interfaz.

## Ejecución local
1. Descarga o clona el repositorio.
2. Abre la carpeta con Visual Studio Code.
3. Ejecuta `index.html` con la extensión Live Server (recomendado), o usa un servidor estático local.
4. Abre las pestañas y prueba cada módulo.

## Estructura
```text
/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── app.js
│   ├── math.js
│   ├── quadratic.js
│   ├── sequences.js
│   └── tests.js
└── README.md
```

## Complejidad (análisis de esta implementación)
| Algoritmo | Tiempo | Espacio | Justificación |
|---|---:|---:|---|
| Probabilidad de dos dados | O(1) | O(1) | Recorre siempre 36 resultados. |
| Partidos `C(n,2)` | O(1) | O(1) | Usa una fórmula directa. |
| Conteo de múltiplos | O(1) | O(1) | Usa división entera mediante `floor`. |
| Viajes mínimos | O(1) | O(1) | Usa `ceil(total/capacidad)`. |
| Cálculo de edades | O(1) | O(1) | Opera sobre tres valores. |
| Verificación de porcentaje | O(1) | O(1) | Calcula y compara una cantidad fija de valores. |
| Ecuación cuadrática | O(1) | O(1) | Número fijo de operaciones. |
| Análisis de secuencia | O(n²) | O(n) | Calcula diferencias y busca ciclos sobre la lista. |
| Suite de 10 pruebas | O(1) | O(1) | El número de pruebas es fijo (10). |

## Precisión numérica
- La fórmula cuadrática estable evita la cancelación catastrófica al calcular raíces reales distintas.
- Se valida el caso `a = 0`: ecuación lineal, incompatible o infinitas soluciones.
- La comparación de porcentajes usa tolerancia basada en `Number.EPSILON` y redondeo a dos decimales.

## Publicación en GitHub Pages
1. Crea un repositorio público en GitHub y sube estos archivos.
2. En **Settings → Pages**, selecciona la rama `main` y la carpeta `/ (root)`.
3. Guarda y espera el enlace público.
4. Copia el enlace en la sección **About** del repositorio.

## Flujo de Git sugerido
Realiza los commits a medida que vayas trabajando; no los inventes ni los hagas todos como un solo commit. Ejemplos:
- `docs: agregar estructura inicial del proyecto`
- `feat: implementar simulador de dados y torneo`
- `feat: agregar cálculos de divisibilidad y logística`
- `feat: implementar problemas de edades y porcentajes`
- `style: diseñar interfaz responsiva`
- `feat: resolver ecuaciones cuadráticas`
- `fix: estabilizar cálculo de raíces reales`
- `feat: agregar detector de secuencias`
- `test: incorporar diez pruebas automatizadas`
- `docs: completar README y guía de despliegue`

## Pendiente de confirmar con el material de clase
La guía pide resolver los **10 desafíos originales** de BairesDev, pero el PDF solo menciona algunos tipos de problemas y el `index.html` recibido contiene cuatro tarjetas iniciales. Esta versión implementa los seis tipos descritos explícitamente en la guía; para completar los diez desafíos originales sin inventar sus enunciados, agrega los otros cuatro ejercicios del taller original cuando tengas esa guía.
