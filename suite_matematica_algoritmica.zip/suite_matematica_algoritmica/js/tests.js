import {probabilityDice,tournamentMatches,countMultiples,logisticsTrips,futureAges,verifyPercentage} from "./math.js";
import {solveQuadratic} from "./quadratic.js";
import {analyzeSequence} from "./sequences.js";
export function runTests(){
 const tests=[
  ["Dados suma 7",()=>probabilityDice(7).outcomes===6],
  ["Torneo con 4 equipos",()=>tournamentMatches(4)===6],
  ["Divisibles menores que 10 entre 3",()=>countMultiples(10,3)===3],
  ["Logística: 17 objetos, capacidad 3",()=>logisticsTrips(17,3)===6],
  ["Edades futuras",()=>futureAges(18,24,5).join(",")==="23,29"],
  ["Porcentaje 2.80 de 8.75",()=>verifyPercentage(2.8,8.75,32).match],
  ["Cuadrática con dos raíces",()=>{const r=solveQuadratic(1,-5,6);return r.kind==="real"&&Math.abs(r.roots[0]-2)<1e-10&&Math.abs(r.roots[1]-3)<1e-10;}],
  ["Cuadrática degenerada lineal",()=>{const r=solveQuadratic(0,2,-6);return r.kind==="linear"&&r.root===3;}],
  ["Caso a=b=c=0",()=>solveQuadratic(0,0,0).kind==="infinite"],
  ["Secuencia geométrica",()=>{const r=analyzeSequence([4,16,64,256]);return r.type==="Geométrica"&&r.next===1024;}]
 ];
 return tests.map(([name,fn],i)=>{try{const ok=Boolean(fn());return {id:i+1,name,pass:ok,detail:ok?"Aserción correcta":"El resultado no coincide"};}catch(e){return {id:i+1,name,pass:false,detail:e.message};}});
}
