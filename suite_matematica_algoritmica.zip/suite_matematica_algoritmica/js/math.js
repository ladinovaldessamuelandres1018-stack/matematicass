export function numberFrom(id){
  const el=document.getElementById(id);
  if(!el || el.value.trim()==="") throw new Error("Completa todos los campos.");
  const value=Number(el.value);
  if(!Number.isFinite(value)) throw new Error("Ingresa un número válido.");
  return value;
}
export function nonNegative(value,label){
  if(value<0) throw new Error(`${label} no puede ser negativo.`);
  return value;
}
export function approximatelyEqual(a,b){
  const scale=Math.max(1,Math.abs(a),Math.abs(b));
  return Math.abs(a-b)<=Number.EPSILON*scale*8;
}
export function probabilityDice(sum){
  if(!Number.isInteger(sum)||sum<2||sum>12) throw new Error("La suma debe ser un entero entre 2 y 12.");
  let outcomes=0;
  for(let d1=1;d1<=6;d1++) for(let d2=1;d2<=6;d2++) if(d1+d2===sum) outcomes++;
  return {outcomes,total:36,percent:outcomes/36*100};
}
export function tournamentMatches(n){
  if(!Number.isInteger(n)||n<2) throw new Error("El número de equipos debe ser un entero mayor o igual a 2.");
  return n*(n-1)/2;
}
export function countMultiples(limit,divisor){
  if(!Number.isInteger(limit)||limit<1) throw new Error("El límite debe ser un entero positivo.");
  if(!Number.isInteger(divisor)||divisor<=0) throw new Error("El divisor debe ser un entero positivo.");
  return Math.floor((limit-1)/divisor);
}
export function logisticsTrips(total,capacity){
  if(!Number.isFinite(total)||total<0) throw new Error("El total no puede ser negativo.");
  if(!Number.isFinite(capacity)||capacity<=0) throw new Error("La capacidad debe ser mayor que cero.");
  return Math.ceil(total/capacity);
}
export function futureAges(a,b,years){
  [a,b,years].forEach((v)=>{if(!Number.isInteger(v)||v<0)throw new Error("Las edades y los años deben ser enteros no negativos.");});
  return [a+years,b+years];
}
export function verifyPercentage(part,total,expected){
  if(part<0||total<=0||expected<0) throw new Error("Usa cantidades no negativas y un total mayor que cero.");
  const actual=part/total*100;
  return {actual,match:approximatelyEqual(actual,expected)||Math.round(actual*100)/100===Math.round(expected*100)/100};
}
