export function analyzeSequence(values){
  if(values.length<3||values.some(v=>!Number.isFinite(v))) throw new Error("Ingresa al menos 3 números válidos.");
  const d1=values.slice(1).map((v,i)=>v-values[i]);
  const d2=d1.slice(1).map((v,i)=>v-d1[i]);
  const last=values.at(-1);
  if(d1.every(x=>x===d1[0])) return {type:"Aritmética",rule:`Sumar ${d1[0]}`,next:last+d1[0],d1,d2};
  if(d2.length&&d2.every(x=>Math.abs(x-d2[0])<1e-9)) return {type:"Aritmética de segundo orden",rule:`La segunda diferencia es ${d2[0]}`,next:last+d1.at(-1)+d2[0],d1,d2};
  const ratio=values.slice(1).map((v,i)=>values[i]===0?NaN:v/values[i]);
  if(ratio.every(Number.isFinite)&&ratio.every(x=>Math.abs(x-ratio[0])<1e-9)) return {type:"Geométrica",rule:`Multiplicar por ${ratio[0]}`,next:last*ratio[0],d1,d2};
  // Para una secuencia dual, se busca un ciclo repetido de operaciones entre términos.
  const ops=values.slice(1).map((v,i)=>values[i]===0?`+${v}`:(v/values[i]===Math.round(v/values[i])?`×${v/values[i]}`:`+${v-values[i]}`));
  for(let period=2;period<=Math.floor(ops.length/2);period++){
    if(ops.every((op,i)=>op===ops[i%period])){
      const op=ops[ops.length%period];
      const next=op.startsWith("×")?last*Number(op.slice(1)):last+Number(op.slice(1));
      return {type:"Dual / patrón repetitivo",rule:`Repite el ciclo ${ops.slice(0,period).join(", ")}`,next,d1,d2};
    }
  }
  return {type:"Patrón no identificado con certeza",rule:"No hay una regla aritmética o geométrica simple detectable.",next:null,d1,d2};
}
