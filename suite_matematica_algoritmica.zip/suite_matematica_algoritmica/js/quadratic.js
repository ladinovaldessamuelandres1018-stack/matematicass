export function solveQuadratic(a,b,c){
  if(![a,b,c].every(Number.isFinite)) throw new Error("Los coeficientes deben ser números finitos.");
  if(a===0){
    if(b===0) return c===0?{kind:"infinite"}:{kind:"incompatible"};
    return {kind:"linear",root:-c/b};
  }
  const delta=b*b-4*a*c;
  const vertexX=-b/(2*a);
  const vertexY=c-(b*b)/(4*a);
  if(delta<0){
    const real=-b/(2*a), imaginary=Math.sqrt(-delta)/(2*Math.abs(a));
    return {kind:"complex",delta,vertexX,vertexY,real,imaginary};
  }
  if(delta===0) return {kind:"double",delta,vertexX,vertexY,roots:[-b/(2*a)]};
  // Fórmula estable de Citardauq: evita restar números casi iguales.
  const signB=b>=0?1:-1;
  const q=-0.5*(b+signB*Math.sqrt(delta));
  let x1,x2;
  if(q===0){x1=(-b+Math.sqrt(delta))/(2*a);x2=(-b-Math.sqrt(delta))/(2*a);}
  else {x1=q/a;x2=c/q;}
  return {kind:"real",delta,vertexX,vertexY,roots:[x1,x2].sort((x,y)=>x-y)};
}
export function drawParabola(canvas,result,a,b,c){
  const ctx=canvas.getContext("2d"),w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);
  const xCenter=Number.isFinite(result.vertexX)?result.vertexX:0;
  const span=Math.max(8,Math.abs(xCenter)*1.5+6);
  const xmin=xCenter-span/2,xmax=xCenter+span/2;
  const samples=100,ys=[];
  for(let i=0;i<=samples;i++){const x=xmin+(xmax-xmin)*i/samples;ys.push(a*x*x+b*x+c);}
  const ymin=Math.min(...ys,0),ymax=Math.max(...ys,0),ypad=(ymax-ymin||1)*.12;
  const low=ymin-ypad,high=ymax+ypad;
  const X=x=>40+(x-xmin)/(xmax-xmin)*(w-55);
  const Y=y=>h-30-(y-low)/(high-low)*(h-55);
  ctx.strokeStyle="#cbd5e1";ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(40,Y(0));ctx.lineTo(w-15,Y(0));ctx.moveTo(X(0),10);ctx.lineTo(X(0),h-30);ctx.stroke();
  ctx.strokeStyle="#2563eb";ctx.lineWidth=2.5;ctx.beginPath();
  for(let i=0;i<=samples;i++){const x=xmin+(xmax-xmin)*i/samples;const y=a*x*x+b*x+c;i?ctx.lineTo(X(x),Y(y)):ctx.moveTo(X(x),Y(y));}
  ctx.stroke();
  if(Number.isFinite(result.vertexX)&&Number.isFinite(result.vertexY)){ctx.fillStyle="#16a34a";ctx.beginPath();ctx.arc(X(result.vertexX),Y(result.vertexY),5,0,Math.PI*2);ctx.fill();}
  if(result.kind==="real"||result.kind==="double"){
    ctx.fillStyle="#dc2626";result.roots.forEach(root=>{if(root>=xmin&&root<=xmax){ctx.beginPath();ctx.arc(X(root),Y(0),5,0,Math.PI*2);ctx.fill();}});
  }
}
