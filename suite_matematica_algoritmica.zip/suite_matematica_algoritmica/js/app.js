import {numberFrom,nonNegative,probabilityDice,tournamentMatches,countMultiples,logisticsTrips,futureAges,verifyPercentage} from "./math.js";
import {solveQuadratic,drawParabola} from "./quadratic.js";
import {analyzeSequence} from "./sequences.js";
import {runTests} from "./tests.js";

const $=id=>document.getElementById(id);
function show(id,message,error=false){const el=$(id);el.textContent=message;el.classList.toggle("error",error);}
function action(buttonId,resultId,fn){$(buttonId)?.addEventListener("click",()=>{try{show(resultId,fn());}catch(e){show(resultId,e.message,true);}});}

document.querySelectorAll(".nav-tab").forEach(button=>button.addEventListener("click",()=>{
 document.querySelectorAll(".nav-tab").forEach(b=>b.classList.toggle("active",b===button));
 document.querySelectorAll(".tab-pane").forEach(p=>p.classList.toggle("active",p.id===button.dataset.tab));
}));

action("btn-calc-dados","res-dados",()=>{const r=probabilityDice(numberFrom("input-dados-suma"));return `${r.outcomes} resultados favorables de 36 posibles. Probabilidad: ${(r.percent).toFixed(2)}%.`;});
action("btn-calc-torneo","res-torneo",()=>`Se jugarán ${tournamentMatches(numberFrom("input-torneo-equipos"))} partidos.`);
action("btn-calc-div","res-div",()=>`Hay ${countMultiples(numberFrom("input-div-limite"),numberFrom("input-div-divisor"))} múltiplos positivos menores que el límite.`);
action("btn-calc-botellas","res-botellas",()=>`Se necesitan ${logisticsTrips(numberFrom("input-botellas-total"),numberFrom("input-botellas-cap"))} viajes.`);
action("btn-calc-edades","res-edades",()=>{const [a,b]=futureAges(numberFrom("edad-persona-a"),numberFrom("edad-persona-b"),numberFrom("edad-anios"));return `Dentro del tiempo indicado, A tendrá ${a} años y B tendrá ${b} años.`;});
action("btn-calc-proporcion","res-proporcion",()=>{const r=verifyPercentage(numberFrom("prop-parte"),numberFrom("prop-total"),numberFrom("prop-porcentaje"));return `Porcentaje calculado: ${r.actual.toFixed(8)}%. ${r.match?"Sí coincide":"No coincide"} con el porcentaje esperado.`;});

function resolve(){
 const a=numberFrom("coef-a"),b=numberFrom("coef-b"),c=numberFrom("coef-c"),r=solveQuadratic(a,b,c);
 $("out-eq").textContent=`${a}x² ${b<0?"-":"+"} ${Math.abs(b)}x ${c<0?"-":"+"} ${Math.abs(c)} = 0`;
 $("out-delta").textContent=r.delta===undefined?"No aplica":String(r.delta);
 $("out-vertice").textContent=r.vertexX===undefined?"No aplica":`(${r.vertexX.toPrecision(6)}, ${r.vertexY.toPrecision(6)})`;
 let type="",roots="";
 if(r.kind==="infinite"){type="Infinitas soluciones";roots="Todos los números reales";}
 else if(r.kind==="incompatible"){type="Ecuación incompatible";roots="No tiene solución";}
 else if(r.kind==="linear"){type="Ecuación lineal";roots=`x = ${r.root}`;}
 else if(r.kind==="complex"){type="Dos raíces complejas conjugadas";roots=`x₁ = ${r.real} + ${r.imaginary}i; x₂ = ${r.real} - ${r.imaginary}i`;}
 else if(r.kind==="double"){type="Una raíz real doble";roots=`x = ${r.roots[0]}`;}
 else{type="Dos raíces reales distintas";roots=`x₁ = ${r.roots[0]}; x₂ = ${r.roots[1]}`;}
 $("out-tipo").textContent=type;$("out-raices").textContent=roots;
 drawParabola($("parabola-canvas"),r,a,b,c);
}
$("btn-resolver-cuadratica")?.addEventListener("click",()=>{try{resolve();}catch(e){$("cuadratica-resultado").textContent=e.message;}});
document.querySelectorAll("[data-a]").forEach(btn=>btn.addEventListener("click",()=>{ $("coef-a").value=btn.dataset.a;$("coef-b").value=btn.dataset.b;$("coef-c").value=btn.dataset.c;try{resolve();}catch(e){}}));
document.querySelectorAll("[data-seq]").forEach(btn=>btn.addEventListener("click",()=>{$("input-secuencia").value=btn.dataset.seq;}));
$("btn-analizar-secuencia")?.addEventListener("click",()=>{try{
 const values=$("input-secuencia").value.split(",").map(s=>s.trim()).filter(Boolean).map(Number);
 if(values.some(v=>!Number.isFinite(v)))throw new Error("La secuencia contiene valores no válidos.");
 const r=analyzeSequence(values);
 show("res-secuencia",`Tipo: ${r.type}. Regla: ${r.rule}.\nDiferencias Δ₁: ${r.d1.join(", ")}.\nDiferencias Δ₂: ${r.d2.join(", ")}.\nSiguiente término: ${r.next===null?"No se puede predecir con certeza":r.next}.`);
 }catch(e){show("res-secuencia",e.message,true);}});
$("btn-run-all-tests")?.addEventListener("click",()=>{
 const results=runTests(),body=$("test-results-body");
 body.innerHTML="";
 results.forEach(t=>{const tr=document.createElement("tr");[t.id,t.name,"Automatizada",t.pass?"PASS":"FAIL",t.detail].forEach((v,i)=>{const td=document.createElement("td");td.textContent=v;if(i===3){const badge=document.createElement("span");badge.className=`badge-status ${t.pass?"pass":"fail"}`;badge.textContent=v;td.textContent="";td.append(badge);}tr.append(td);});body.append(tr);});
 const passed=results.filter(t=>t.pass).length,failed=results.length-passed;
 $("test-summary-badges").innerHTML=`<span class="badge-status pass">${passed} Pass</span> <span class="badge-status ${failed?"fail":"pass"}">${failed} Fail</span>`;
});
try{resolve();}catch(e){console.warn(e);}
